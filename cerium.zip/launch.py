import os
from cerium.load import load

window = 'mode 90,19'
os.system(window)
load()