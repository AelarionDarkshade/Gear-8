class config:
    global auth; auth = "" # Enter your discord token for Auto-Login.
    global prefix; prefix = "c." # Enter your prefix for selfbot.
    global nitro_sniper; nitro_sniper = "true" # 'true' to enable nitro sniper, 'false' to disable.
    global giveaway_sniper; giveaway_sniper = "true" # 'true' to enable giveaway sniper, 'false' to disable.
