import discord, pyfiglet
from discord.ext import commands as cerium

class wl(cerium.Cog):
    def __init__(self, bot):
        self.bot = bot

    @cerium.group()
    async def wl(self, ctx):
        if ctx.invoked_subcommand is None:
            await ctx.send('Invalid subcommand! Use `add`, `remove`, or `list`.')

    @wl.command()
    async def add(self, ctx, user: discord.Member):
        if ctx.guild.id in antinuke_servers:
            if user.id not in antinuke_whitelist:
                antinuke_whitelist.append(user.id)
                with open('antinuke_whitelist.json', 'w') as f:
                    json.dump(antinuke_whitelist, f)
                await ctx.send(f'User {user.mention} has been added to the whitelist!')
            else:
                await ctx.send('User is already in the whitelist!')
        else:
            await ctx.send('Antinuke is not enabled for this server!')

    @wl.command()
    async def remove(self, ctx, user: discord.Member):
        if ctx.guild.id in antinuke_servers:
            if user.id in antinuke_whitelist:
                antinuke_whitelist.remove(user.id)
                with open('antinuke_whitelist.json', 'w') as f:
                    json.dump(antinuke_whitelist, f)
                await ctx.send(f'User {user.mention} has been removed from the whitelist!')
            else:
                await ctx.send('User is not in the whitelist!')
        else:
            await ctx.send('Antinuke is not enabled for this server!')

    @wl.command()
    async def list(self, ctx):
        if ctx.guild.id in antinuke_servers:
            whitelist_users = [self.bot.get_user(uid) for uid in antinuke_whitelist]
            whitelist_usernames = [f'{user.name}#{user.discriminator}' for user in whitelist_users]
            await ctx.send(f'Whitelisted users: {", ".join(whitelist_usernames)}')
        else:
            await ctx.send('Antinuke is not enabled for this server!')

def setup(bot):
    bot.add_cog(wl(bot))