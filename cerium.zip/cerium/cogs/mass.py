import discord, pyfiglet, ast
from discord.ext import commands as cerium

class mass(cerium.Cog):
    def __init__(self, bot):
        self.bot = bot

    @cerium.command()
    async def massreact(self, ctx, emote):
        await ctx.message.delete()
        messages = await ctx.message.channel.history(limit=20).flatten()
        for message in messages:
            await message.add_reaction(emote)

    @cerium.command()
    async def spam(self, ctx, amount: int = None, *, message: str = None):
        await ctx.message.delete()
        for each in range(0, amount):
            await ctx.send(f"{message}")

    @cerium.command(aliases=['sc'])
    async def masschannelcreate(self, ctx, amount: int = None, *, name: str = None):
        if amount is None or name is None:
            await ctx.send('Please provide the amount and name of the channels to create.')
            return
        for each in range(amount):
            await ctx.guild.create_text_channel(f'{name}')
        await ctx.send(f'Created {amount} channels named "{name}"')

    @cerium.command(aliases=['sr'])
    async def massrolecreate(self, ctx, amount: int = None, *, name: str = None):
        if amount is None or name is None:
            await ctx.send('Please provide the amount and name of the roles to create.')
            return
        for each in range(amount):
            await ctx.guild.create_role(name=f'{name}')
        await ctx.send(f'Created {amount} roles named "{name}"')

    @cerium.command(name="eval", description="Evaluates a python expression", usage="eval <expression>")
    async def eval(self, ctx, *, expression):
        
        def _insert_returns(body):
            # Insert return statements if needed
            if isinstance(body[-1], ast.Expr):
                body[-1] = ast.Return(body[-1].value)
                ast.fix_missing_locations(body[-1])
            if isinstance(body[-1], ast.If):
                _insert_returns(body[-1].body) 
                _insert_returns(body[-1].orelse)
            if isinstance(body[-1], ast.With):
                _insert_returns(body[-1].body)

        fn_name = "_eval_expr"
        expression = expression.strip("` ")

        expression = "
".join(f"    {i}" for i in expression.splitlines())

        body = f"async def {fn_name}():
{expression}"

        parsed = ast.parse(body)
        body = parsed.body[0].body

        _insert_returns(body)

        env = {
            'bot': ctx.bot,
            'discord': discord,
            'commands': cerium,
            'ctx': ctx,
            '__import__': __import__
        }

        exec(compile(parsed, filename="<ast>", mode="exec"), env)

        result = (await eval(f"{fn_name}()", env))
        await ctx.send(result)

def setup(bot):
    bot.add_cog(mass(bot))