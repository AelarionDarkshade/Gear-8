import discord, requests, pyfiglet
from discord.ext import commands as cerium
from cerium.load import token

Output = "cerium || "

class Activity(cerium.Cog):
    def __init__(self, bot):
        self.bot = bot


    @cerium.command()
    async def streaming(self, ctx, *, message):
        await ctx.message.delete()
        await ctx.send("Okay Babe, Successfully Set your streaming activity")
        stream = discord.Streaming(
            name = message,
            url = "https://www.twitch.tv/cerium", 
        )
        await self.bot.change_presence(activity=stream)    

        
    @cerium.command()
    async def playing(self, ctx, *, message):
        await ctx.message.delete()
        await ctx.send("Okay Babe, Successfully Set your playing activity")        
        game = discord.Game(
            name=message
        )
        await self.bot.change_presence(activity=game)
    
    
    @cerium.command()
    async def listening(self, ctx, *, message):
        await ctx.message.delete()
        await ctx.send("Okay Babe, Successfully Set your listening activity")        
        await self.bot.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.listening, 
                name=message, 
            ))
           
            
    @cerium.command()
    async def watching(self, ctx, *, message):
        await ctx.message.delete()
        await ctx.send("Okay Babe, Successfully Set your watching activity")        
        await self.bot.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching, 
                name=message
            ))


    @cerium.command(aliases=["stopstreaming", "stopstatus", "stoplistening", "stopplaying", "stopwatching"])
    async def stopactivity(self, ctx):
        await ctx.message.delete()
        await ctx.send("done! cleared your activity")
        await self.bot.change_presence(activity=None, status=discord.Status.dnd)


def setup(bot):
    bot.add_cog(Activity(bot))