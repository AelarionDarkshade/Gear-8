import discord, pyfiglet
from discord.ext import commands as cerium 


class antinuke(cerium.Cog):
    def __init__(self, bot):
        self.bot = bot

    @cerium.command()
    async def antinuke(self, ctx, toggle: str):
        if toggle.lower() == 'enable':
            if ctx.guild.id not in antinuke_servers:
                antinuke_servers.append(ctx.guild.id)
                with open('antinuke_servers.json', 'w') as f:
                    json.dump(antinuke_servers, f)
                await ctx.send('Antinuke has been enabled for this server!')
            else:
                await ctx.send('Antinuke is already enabled for this server!')
        elif toggle.lower() == 'disable':
            if ctx.guild.id in antinuke_servers:
                antinuke_servers.remove(ctx.guild.id)
                with open('antinuke_servers.json', 'w') as f:
                    json.dump(antinuke_servers, f)
                await ctx.send('Antinuke has been disabled for this server!')
            else:
                await ctx.send('Antinuke is already disabled for this server!')
        else:
            await ctx.send('Invalid toggle argument! Use `enable` or `disable`.')

    @cerium.command()
    async def antinukefeatures(self, ctx):
        await ctx.send('''
Antinuke Features: (Coming Soon)
- AntiKick 
- AntiBan
- AntiChannel Create/Delete
- AntiRole Create/Delete || Assign/Remove
''')

def setup(bot):
    bot.add_cog(antinuke(bot))
